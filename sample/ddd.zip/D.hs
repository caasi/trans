module D where

foo = "bar"
